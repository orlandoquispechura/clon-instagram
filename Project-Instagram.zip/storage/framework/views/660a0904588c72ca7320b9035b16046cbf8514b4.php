<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">

    <!-- Styles -->
    
    

    <!-- Scripts -->
    
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js', 'resources/sass/app.scss']); ?>

</head>

<body class="bg-light font-sans antialiased">
    <?php echo e($slot); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\Project-Instagram\resources\views/layouts/guest.blade.php ENDPATH**/ ?>