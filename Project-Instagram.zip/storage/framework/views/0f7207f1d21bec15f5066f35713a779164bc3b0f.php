<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
     <?php $__env->endSlot(); ?>
    <div class="container mt-5">
        <div class="row">
            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-12 col-md-7 col-lg-7 m-auto mb-4">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php elseif(session('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="card">
                        <div class="card-header">
                            <a style="color: #444" href="<?php echo e(route('admin.user.perfil', $img->user->id)); ?>">
                                <strong><?php echo e('@' . $img->user->name); ?> | User</strong>
                            </a>
                        </div>
                        <div class="card-body p-0">
                            <div style="max-height: 400px; overflow: hidden;">
                                <img style="width: 100%; height: 100%; object-fit: cover; "
                                    src="<?php echo e(route('admin.image.file', ['img' => $img->ruta_imagen])); ?>" alt=" logo ">
                            </div>
                            <div style="padding: 3px 15px">
                                <strong><?php echo e('@' . $img->user->name); ?></strong>
                                <strong><?php echo e(' | ' . $img->created_at->diffForHumans()); ?></strong>
                                <p>
                                    <?php echo e($img->descripcion); ?>

                                </p>
                            </div>
                            <div style="padding: 0px 0px 15px 15px">
                                <?php $user_like = false; ?>
                                <?php $__currentLoopData = $img->likes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $like): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($like->user->id == Auth::user()->id): ?>
                                        <?php $user_like = true; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php if($user_like): ?>
                                    <img style="width: 20px; cursor:pointer;" data-id="<?php echo e($img->id); ?>"
                                        src="<?php echo e(asset('icons/heart-red.png')); ?>" alt="icon de me gusta"
                                        class="icon-like">
                                <?php else: ?>
                                    <img style="width: 20px; cursor:pointer;" data-id="<?php echo e($img->id); ?>"
                                        src="<?php echo e(asset('icons/heart-black.png')); ?>" alt="icon sin me gusta"
                                        class="icon-dislike">
                                <?php endif; ?>
                                <span style="font-size: 0.6rem; margin-right: 5px;"> <?php echo e(count($img->likes)); ?></span>
                                <a href="<?php echo e(route('admin.image.show', $img->id)); ?>" class="btn btn-sm btn-light fw-bold">comentarios
                                    (<?php echo e(count($img->comments)); ?>)
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($images->links()); ?>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>

<script>
    var url = 'http://localhost:8000';

    window.addEventListener("load", function() {

        function like() {
            $('.icon-like').unbind('click').click(function() {
                console.log('like');
                $(this).addClass('icon-dislike').removeClass('btn-like');
                $(this).attr('src', 'icons/heart-red.png');

                $.ajax({
                    url: url + '/like/' + $(this).data('id'),
                    type: 'GET',
                    success: function(response) {
                        console.log(response);
                        if (response.like) {
                            console.log('like');
                        } else {
                            console.log('no like');
                        }
                    }
                });

                dislike();
            });
        }
        like();



        function dislike() {
            $('.icon-dislike').unbind('click').click(function() {
                console.log('dislike');
                $(this).addClass('icon-like').removeClass('btn-dislike');
                $(this).attr('src', 'icons/heart-black.png');

                $.ajax({
                    url: url + '/dislike/' + $(this).data('id'),
                    type: 'GET',
                    success: function(response) {
                        console.log(response);
                        if (response.like) {
                            console.log('dislike');
                        } else {
                            console.log('no dislike');
                        }
                    }
                });

                like();
            });
        }
        dislike();


    })


</script>
<?php /**PATH C:\xampp\htdocs\Project-Instagram\resources\views/admin/user/perfil.blade.php ENDPATH**/ ?>