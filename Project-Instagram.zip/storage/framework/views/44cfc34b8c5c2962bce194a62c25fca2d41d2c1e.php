
<a class="d-flex justify-content-center mb-4" href="/">
    <img width="100" fill="none" viewbox="0 0 48 48" src="https://png.pngtree.com/element_our/20190603/ourlarge/pngtree-mbe-icon-camera-image_1440686.jpg"
        alt="icono-login">
</a>
<?php /**PATH C:\xampp\htdocs\Project-Instagram\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>