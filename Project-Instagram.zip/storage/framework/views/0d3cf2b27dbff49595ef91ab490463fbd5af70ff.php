

<a class="d-flex justify-content-center mb-4" href="/">
    <img class="rounded-circle mt-3" height="40px" width="40px"   fill="none" viewbox="0 0 48 48"
        src="https://previews.123rf.com/images/yupiramos/yupiramos1708/yupiramos170808431/83723218-icono-de-la-c%C3%A1mara-fotogr%C3%A1fica-sobre-fondo-blanco-ilustraci%C3%B3n-vectorial.jpg"
        alt="icono-login">
</a>
<?php /**PATH C:\xampp\htdocs\Project-Instagram\resources\views/vendor/jetstream/components/application-mark.blade.php ENDPATH**/ ?>