<div class="py-3">
    <hr />
</div>
<?php /**PATH C:\xampp\htdocs\Project-Instagram\resources\views/vendor/jetstream/components/section-border.blade.php ENDPATH**/ ?>