<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
     <?php $__env->endSlot(); ?>
    <div class="container">
        <form action="<?php echo e(route('admin.user.index')); ?>" id="buscador"method="GET" class="row mb-5">

            <div class="col-md-6">
                <input type="text" id="search" class="form-control" placeholder="Buscar personas...">
            </div>
            <div class="col-md-2">
                <input type="submit" value="Buscar" class="btn btn-info text-white">
            </div>
        </form>
        <div class="row">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body p-0 w-100">
                            <img src="<?php echo e($user->profile_photo_url); ?>" width="100%" alt="user"
                                class="img-fluid rounded">
                            
                        </div>
                        <div class="card-footer">
                            <h3><?php echo e('@' . Str::ucfirst($user->name)); ?></h3>
                            <h6><?php echo e(' Se unió: ' . Str::ucfirst($user->created_at->diffForHumans())); ?></h6>
                            <a href="<?php echo e(route('admin.user.publicacion', $user->id)); ?>"
                                class="btn btn-sm btn-primary text-white">Ver perfil</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>

<script>
    var url = 'http://localhost:8000';
    
    window.addEventListener("load", function() {
        // alert('alerta');
        $('#buscador').submit(function(e) {
            $(this).attr('action' , url+'/personas/' + $('#buscador #search').val());
        });
    })
</script>

<?php /**PATH C:\xampp\htdocs\Project-Instagram\resources\views/admin/user/index.blade.php ENDPATH**/ ?>